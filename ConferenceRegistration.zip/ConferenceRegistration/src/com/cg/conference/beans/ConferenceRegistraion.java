package com.cg.conference.beans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistraion {

	@FindBy(how = How.ID, id = "txtFirstName")
	WebElement firstName;
	
	@FindBy(how = How.ID, id = "txtLastName")
	WebElement lastName;
	
	@FindBy(how = How.ID, id = "txtEmail")
	WebElement email;
	
	@FindBy(how = How.ID, id = "txtPhone")
	WebElement phone;
	
	@FindBy(how = How.ID, name = "size")
	WebElement noOfPeople;
	

	@FindBy(how = How.ID, id = "txtAddress1")
	WebElement building;
	
	@FindBy(how = How.ID, id = "txtAddress2")
	WebElement areaName;
	
	@FindBy(how = How.ID, name = "city")
	WebElement city;
	
	@FindBy(how = How.ID, name = "state")
	WebElement state;

	@FindBy(how = How.ID, name = "memberStatus")
	List<WebElement> memberStatus;
	
	@FindBy(how = How.LINK_TEXT, linkText="Next" )
	WebElement next;

	@FindBy(how = How.ID, id = "txtCardholderName")
	WebElement cardHolder;
	@FindBy(how = How.ID, id = "txtDebit")
	WebElement debitCardNumber;
	@FindBy(how = How.ID, id = "txtCvv")
	WebElement cvv;
	@FindBy(how = How.ID, id = "txtMonth")
	WebElement expirationMonth;
	@FindBy(how = How.ID, id = "txtYear")
	WebElement expirationYear;

	@FindBy(how = How.ID, id = "btnPayment")
	WebElement button;
	
	
	public ConferenceRegistraion() {

	}

	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPhone() {
		return this.phone.getAttribute("value");
	}

	public void setPhone(String phone) {
		this.phone.clear();
		this.phone.sendKeys(phone);
	}

	public void setNoOfPeoples(int option)
	{
		Select select=new Select(noOfPeople);
		select.selectByIndex(option);
	}

	public String getBuilding() {
		return this.phone.getAttribute("value");
	}

	public void setBuilding(String building) {
		this.building.sendKeys(building);
	}

	public String getAreaName() {
		return this.areaName.getAttribute("value");
	}

	public void setAreaName(String areaName) {
		this.areaName.sendKeys(areaName);
	}

	public void setCity(String option)
	{
		Select select=new Select(city);
		select.selectByVisibleText(option);
	}
	
	public void setState(String option)
	{
		Select select=new Select(state);
		select.selectByVisibleText(option);
	}
	public void setMemberStatus(String option)
	{
		List<WebElement>  oRadioButton = memberStatus;

		if(option.equals("0"))
			oRadioButton.get(0).click();
		
		if(option.equals("1"))
			oRadioButton.get(1).click();
		
	}
	
	public void clickNext()
	{
		next.click();
	}
	
	

	public String getCardHolder() {
		return this.cardHolder.getAttribute("value");
	}

	public void setCardHolder(String cardHolder) {
		this.cardHolder.sendKeys(cardHolder);
	}

	public String getDebitCardNumber() {
		return this.debitCardNumber.getAttribute("value");
	}

	public void setDebitCardNumber(String debitCardNumber) {
		this.debitCardNumber.sendKeys(debitCardNumber);
	}

	public String getCvv() {
		return this.cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public String getExpirationMonth() {
		return this.expirationMonth.getAttribute("value");
	}

	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth.sendKeys(expirationMonth);
	}

	public String getExpirationYear() {
		return this.expirationYear.getAttribute("value");
	}

	public void setExpirationYear(String expirationYear) {
		this.expirationYear.sendKeys(expirationYear);
	}

	public void clickButton() {
		button.click();
	}
	
	
}
