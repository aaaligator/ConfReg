package com.cg.conference.stepdefinitions;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.conference.beans.ConferenceRegistraion;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferneceRegistrationStepDefinitions {
	private WebDriver driver;
	private ConferenceRegistraion conf;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\\\Software\\\\Selenium\\\\driver\\\\chromedriver.exe");

	}

	@Given("^User Opens Web Browser$")
	public void user_Opens_Web_Browser() throws Throwable {
		driver = new ChromeDriver();
		conf = new ConferenceRegistraion();
		PageFactory.initElements(driver, conf);

	}

	@When("^User Enters URL of 'ConferenceRegistartion\\.html'$")
	public void user_Enters_URL_of_ConferenceRegistartion_html() throws Throwable {
		driver.get("D:\\Lalit Nikhare\\bdd_final\\ConferenceRegistration\\MyWebApp\\ConferenceRegistartion.html");

	}

	@Then("^Browser Should Open the Web Page$")
	public void browser_Should_Open_the_Web_Page() throws Throwable {
		assertEquals("Conference Registartion", driver.getTitle());
	}

	@When("^User Click on 'Next' without entering 'First Name'$")
	public void user_Click_on_Next_without_entring_First_Name() throws Throwable {
		conf.clickNext();
	}

	@Then("^'Please fill the First Name' message should display$")
	public void please_fill_the_First_Name_message_should_display() throws Throwable {
		assertEquals("Please fill the First Name", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' without entering 'Last Name'$")
	public void user_Click_on_Next_without_entring_Last_Name() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setFirstName("John");
		conf.clickNext();
	}

	@Then("^'Please fill the Last Name' message should display$")
	public void please_fill_the_Last_Name_message_should_display() throws Throwable {
		assertEquals("Please fill the Last Name", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' without entering 'Email'$")
	public void user_Click_on_Next_without_entring_Email() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setLastName("Doe");
		conf.clickNext();
	}

	@Then("^'Please fill the Email' message should display$")
	public void please_fill_the_Email_message_should_display() throws Throwable {
		assertEquals("Please fill the Email", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' without entering 'Contact No\\.'$")
	public void user_Click_on_Next_without_entring_Contact_No() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setEmail("johndoe@gmail.com");
		conf.clickNext();
	}

	@Then("^'Please fill the Contact No\\.' message should display$")
	public void please_fill_the_Contact_No_message_should_display() throws Throwable {
		assertEquals("Please fill the Contact No.", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' with entering Wrong 'Contact No\\.'$")
	public void user_Click_on_Next_with_entring_Wrong_Contact_No() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setPhone("2132132131");
		conf.clickNext();

	}

	@Then("^'Please enter valid Contact no\\.' message should display$")
	public void please_enter_valid_Contact_no_message_should_display() throws Throwable {
		assertEquals("Please enter valid Contact no.", driver.switchTo().alert().getText());

	}

	@When("^User Click on 'Next' without entering 'No of People Attending'$")
	public void user_Click_on_Next_without_entring_No_of_People_Attending() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setPhone("9955882221");
		conf.clickNext();
	}

	@Then("^'Please fill the Number of people attending' message should display$")
	public void please_fill_the_Number_of_people_attending_message_should_display() throws Throwable {
		assertEquals("Please fill the Number of people attending", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' without entering 'Building & Room No'$")
	public void user_Click_on_Next_without_entring_Building_Room_No() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setNoOfPeoples(2);
		conf.clickNext();
	}

	@Then("^'Please fill the Building & Room No' message should display$")
	public void please_fill_the_Building_Room_No_message_should_display() throws Throwable {
		assertEquals("Please fill the Building & Room No", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' without entering 'Area name'$")
	public void user_Click_on_Next_without_entring_Area_name() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setBuilding("Capgemini no 4");
		conf.clickNext();
	}

	@Then("^'Please fill the Area name' message should display$")
	public void please_fill_the_Area_name_message_should_display() throws Throwable {
		assertEquals("Please fill the Area name", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' without entering 'City'$")
	public void user_Click_on_Next_without_entering_City() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setAreaName("Hinjewadi");
		;
		conf.clickNext();
	}

	@Then("^'Please select city' message should display$")
	public void please_select_city_message_should_display() throws Throwable {
		assertEquals("Please select city", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' without entering 'State'$")
	public void user_Click_on_Next_without_entering_State() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setCity("Pune");
		conf.clickNext();
	}

	@Then("^'Please select state' message should display$")
	public void please_select_state_message_should_display() throws Throwable {
		assertEquals("Please select state", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' without entering 'MembershipStatus'$")
	public void user_Click_on_Next_without_entering_MembershipStatus() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setState("Maharashtra");
		conf.clickNext();
	}

	@Then("^'Please Select MemeberShip status' message should display$")
	public void please_Select_MemeberShip_status_message_should_display() throws Throwable {
		assertEquals("Please Select MemeberShip status", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Next' After Entering All the Values$")
	public void user_Click_on_Next_After_Entering_All_the_Values() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setMemberStatus("1");
		conf.clickNext();
	}

	@Then("^'Personal details are validated\\.' message should display$")
	public void personal_details_are_validated_message_should_display() throws Throwable {
		assertEquals("Personal details are validated.", driver.switchTo().alert().getText());
	}

	@When("^User Goes to 'PaymentDetails\\.html' after clicking 'Next'$")
	public void user_Goes_to_PaymentDetails_html_after_clicking_Next() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Then("^Browser should redirect to that page$")
	public void browser_should_redirect_to_that_page() throws Throwable {
		assertEquals("Payment Details", driver.getTitle());
	}

	@When("^User Click on 'Make Payment' without entering 'Card Holder Name'$")
	public void user_Click_on_Next_without_entering_Card_Holder_Name() throws Throwable {
		conf.clickButton();
	}

	@Then("^'Please fill the Card holder name' message should display$")
	public void please_fill_the_Card_holder_name_message_should_display() throws Throwable {
		assertEquals("Please fill the Card holder name", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Make Payment' without entering 'Debit card Number'$")
	public void user_Click_on_Next_without_entering_Debit_card_Number() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setCardHolder("JOHN DOE");
		conf.clickButton();
	}

	@Then("^'Please fill the Debit card Number' message should display$")
	public void please_fill_the_Debit_card_Number_message_should_display() throws Throwable {
		assertEquals("Please fill the Debit card Number", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Make Payment' without entering 'CVV'$")
	public void user_Click_on_Next_without_entering_CVV() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setDebitCardNumber("12345678910");
		conf.clickButton();
	}

	@Then("^'Please fill the CVV' message should display$")
	public void please_fill_the_CVV_message_should_display() throws Throwable {
		assertEquals("Please fill the CVV", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Make Payment' without entering 'expiration month'$")
	public void user_Click_on_Next_without_entering_expiration_month() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setCvv("456");
		conf.clickButton();
	}

	@Then("^'Please fill expiration month' message should display$")
	public void please_fill_expiration_month_message_should_display() throws Throwable {
		assertEquals("Please fill expiration month", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Make Payment' without entering 'expiration year'$")
	public void user_Click_on_Next_without_entering_expiration_year() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setExpirationMonth("08");
		conf.clickButton();
	}

	@Then("^'Please fill the expiration year' message should display$")
	public void please_fill_the_expiration_year_message_should_display() throws Throwable {
		assertEquals("Please fill the expiration year", driver.switchTo().alert().getText());
	}

	@When("^User Click on 'Make Payment' After Entering All the Values$")
	public void user_Click_on_Make_Payment_After_Entering_All_the_Values() throws Throwable {
		driver.switchTo().alert().accept();
		conf.setExpirationYear("2020");
		conf.clickButton();
	}

	@Then("^'Conference Room Booking successfully done!!!' message should display$")
	public void conference_Room_Booking_successfully_done_message_should_display() throws Throwable {
		assertEquals("Conference Room Booking successfully done!!!", driver.switchTo().alert().getText());
		driver.close();
	}

}
